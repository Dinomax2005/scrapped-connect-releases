Lately — static website bundle
==============================

This is the ready-to-host Lately social website. Its accounts and shared posts use the dedicated Lately Social Supabase project.

LOCAL PREVIEW
-------------
1. Install Python 3.
2. In this folder, run: python3 -m http.server 8000
   Windows may use: py -m http.server 8000
3. Open http://localhost:8000

HOSTING
-------
Upload the contents of this folder to an HTTPS static host. Add your final domain to Supabase → Authentication → URL Configuration before using email links on that domain.

EMAIL
-----
Email confirmation and password recovery are enabled. Reliable SMTP has not yet been configured or tested for this project. Set up a custom SMTP sender in Supabase before inviting other people; the default sender is intended for development and may be rate-limited.

PRIVACY AND SECURITY
--------------------
config.js contains only the browser-safe Supabase project URL and publishable key. Do not replace it with a secret or service-role key. The database uses row-level security. Names, usernames, bios, and uploaded photos are publicly readable; posts require a signed-in account. Email addresses are not included in public profiles. Do not post private images.

The first feed includes fictional sample people and posts.
